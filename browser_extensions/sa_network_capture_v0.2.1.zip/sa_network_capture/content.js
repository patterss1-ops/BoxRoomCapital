(function () {
  var lastEndpoint = "";

  function injectHook() {
    var parent = document.documentElement || document.head;
    if (!parent) {
      setTimeout(injectHook, 25);
      return;
    }
    var script = document.createElement("script");
    script.src = chrome.runtime.getURL("page_hook.js");
    script.dataset.extensionVersion = chrome.runtime.getManifest().version;
    parent.appendChild(script);
    script.onload = function () {
      dispatchEndpoint(lastEndpoint);
      script.remove();
    };
  }

  function dispatchEndpoint(endpoint) {
    lastEndpoint = String(endpoint || "").trim();
    var parent = document.documentElement || document;
    if (!parent) return;
    parent.dispatchEvent(new CustomEvent("brc-sa-endpoint", {
      detail: { endpoint: lastEndpoint }
    }));
  }

  injectHook();

  chrome.storage.sync.get({ endpoint: "" }, function (data) {
    dispatchEndpoint(data.endpoint || "");
  });

  chrome.storage.onChanged.addListener(function (changes, area) {
    if (area !== "sync" || !changes.endpoint) return;
    dispatchEndpoint(changes.endpoint.newValue || "");
  });
})();
