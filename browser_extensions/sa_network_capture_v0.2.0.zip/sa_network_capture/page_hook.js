(function () {
  var EXT_VERSION = (document.currentScript && document.currentScript.dataset.extensionVersion) || "0.2.0";
  var CAPTURE_SOURCE = "sa-network-extension";
  var HIDDEN_CONTAINER_ID = "brc-sa-hidden-routes";
  var FRAME_SETTLE_MS = 1800;
  var FRAME_MAX_MS = 6500;
  var FLUSH_IDLE_MS = 1500;
  var MAX_RAW_RESPONSES = 32;
  var endpoint = "";
  var captureState = null;
  var GRADE_MAP = {
    1: "F",
    2: "D-",
    3: "D",
    4: "D+",
    5: "C-",
    6: "C",
    7: "C+",
    8: "B-",
    9: "B",
    10: "B+",
    11: "A-",
    12: "A",
    13: "A+"
  };
  var FALLBACK_ROUTE_SPECS = [
    { section: "quant_ratings", suffix: "/ratings/quant-ratings" },
    { section: "author_ratings", suffix: "/ratings/author-ratings" },
    { section: "sell_side_ratings", suffix: "/ratings/sell-side-ratings" },
    { section: "valuation", suffix: "/valuation/metrics" },
    { section: "earnings", suffix: "/earnings/earnings-revisions" },
    { section: "dividends", suffix: "/dividends/dividend-scorecard" },
    { section: "financials", suffix: "/financials/income-statement" },
    { section: "financials", suffix: "/financials/balance-sheet" },
    { section: "financials", suffix: "/financials/cash-flow-statement" },
    { section: "peers", suffix: "/peers/comparison" }
  ];

  function cleanText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function isTopFrame() {
    try {
      return window.top === window;
    } catch (err) {
      return false;
    }
  }

  function normalizeHref(href, baseHref) {
    try {
      var url = new URL(href, baseHref || window.location.href);
      url.hash = "";
      return url.toString();
    } catch (err) {
      return "";
    }
  }

  function symbolFromPath(pathname) {
    var match = String(pathname || "").match(/\/symbol\/([A-Z0-9.=\-]+)/i);
    return match ? match[1].toUpperCase() : "";
  }

  function symbolFromHref(href) {
    try {
      return symbolFromPath(new URL(href, window.location.href).pathname);
    } catch (err) {
      return "";
    }
  }

  function symbolFromLocation() {
    return symbolFromPath(window.location.pathname || "");
  }

  function toNumber(value) {
    if (value == null || value === "") return null;
    var numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
  }

  function ratingFromScore(score) {
    var numeric = toNumber(score);
    if (numeric == null) return "";
    if (numeric >= 4.5) return "strong buy";
    if (numeric >= 3.5) return "buy";
    if (numeric >= 2.5) return "hold";
    if (numeric >= 1.5) return "sell";
    return "strong sell";
  }

  function gradeFromNumeric(value) {
    var numeric = toNumber(value);
    if (numeric == null) return "";
    var rounded = Math.round(numeric);
    return GRADE_MAP[rounded] || "";
  }

  function latestHistoryEntry(payload) {
    var data = payload && payload.data;
    if (!Array.isArray(data)) return null;
    for (var i = 0; i < data.length; i++) {
      var item = data[i];
      var attrs = item && item.attributes;
      var ratings = attrs && attrs.ratings;
      if (!ratings || typeof ratings !== "object") continue;
      if (ratings.quantRating == null && ratings.sellSideRating == null && ratings.authorsRating == null) {
        continue;
      }
      return item;
    }
    return null;
  }

  function clonePayload(value) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (err) {
      return null;
    }
  }

  function isInterestingPayload(payload, responseUrl, frameUrl) {
    if (!payload || typeof payload !== "object") return false;
    var combined = [cleanText(responseUrl), cleanText(frameUrl)].join(" ").toLowerCase();
    if (combined.indexOf("/symbol/") === -1) return false;
    if (latestHistoryEntry(payload)) return true;
    if (/(ratings|quant|valuation|earnings|dividend|financial|peer)/.test(combined)) {
      return true;
    }
    return Array.isArray(payload.data) && payload.data.length > 0;
  }

  function classifySection(responseUrl, frameUrl, payload) {
    var url = cleanText(responseUrl || frameUrl || "").toLowerCase();
    if (latestHistoryEntry(payload)) return "ratings_history";
    if (url.indexOf("/ratings/quant-ratings") !== -1) return "quant_ratings";
    if (url.indexOf("/ratings/author-ratings") !== -1) return "author_ratings";
    if (url.indexOf("/ratings/sell-side-ratings") !== -1) return "sell_side_ratings";
    if (url.indexOf("/valuation/") !== -1) return "valuation";
    if (url.indexOf("/earnings/") !== -1) return "earnings";
    if (url.indexOf("/dividend") !== -1 || url.indexOf("/dividends/") !== -1) return "dividends";
    if (
      url.indexOf("/financial") !== -1 ||
      url.indexOf("income-statement") !== -1 ||
      url.indexOf("balance-sheet") !== -1 ||
      url.indexOf("cash-flow") !== -1
    ) {
      return "financials";
    }
    if (url.indexOf("/peers/") !== -1) return "peers";
    return "symbol";
  }

  function extractSummaryPatch(payload, responseUrl) {
    var entry = latestHistoryEntry(payload);
    if (!entry) return {};

    var attrs = entry.attributes || {};
    var ratings = attrs.ratings || {};
    return {
      quant_score: toNumber(ratings.quantRating),
      rating: ratingFromScore(ratings.quantRating),
      author_rating: ratingFromScore(ratings.authorsRating),
      wall_st_rating: ratingFromScore(ratings.sellSideRating),
      grades: {
        value: gradeFromNumeric(ratings.valueGrade),
        growth: gradeFromNumeric(ratings.growthGrade),
        profitability: gradeFromNumeric(ratings.profitabilityGrade),
        momentum: gradeFromNumeric(ratings.momentumGrade),
        revisions: gradeFromNumeric(
          ratings.epsRevisionsGrade != null ? ratings.epsRevisionsGrade : ratings.revisionsGrade
        )
      },
      raw_fields: {
        response_url: cleanText(responseUrl || ""),
        as_date: cleanText(attrs.asDate || ""),
        ticker_id: attrs.tickerId != null ? attrs.tickerId : null,
        sa_history_id: cleanText(entry.id || "")
      }
    };
  }

  function createInitialSummary(symbol) {
    var pageUrl = normalizeHref(window.location.href);
    return {
      ticker: symbol,
      url: pageUrl,
      title: cleanText(document.title),
      page_type: "symbol",
      captured_at: new Date().toISOString(),
      rating: "",
      quant_score: null,
      author_rating: "",
      wall_st_rating: "",
      grades: {},
      bookmarklet_version: "sa-network-extension-" + EXT_VERSION,
      source: CAPTURE_SOURCE,
      source_ref: pageUrl,
      raw_fields: {
        source: CAPTURE_SOURCE,
        extension_version: EXT_VERSION
      }
    };
  }

  function ensureCaptureState() {
    if (!isTopFrame()) return null;
    if (captureState) return captureState;
    var symbol = symbolFromLocation();
    if (!symbol) return null;
    var pageUrl = normalizeHref(window.location.href);
    captureState = {
      symbol: symbol,
      pageUrl: pageUrl,
      started: false,
      posted: false,
      pendingRoutes: 0,
      rawResponses: [],
      rawResponseKeys: {},
      sections: {},
      routeDebug: [{ source: "current_page", url: pageUrl }],
      summary: createInitialSummary(symbol),
      flushTimer: 0
    };
    syncDebugFields(captureState);
    return captureState;
  }

  function mergeGrades(target, source) {
    if (!source || typeof source !== "object") return;
    Object.keys(source).forEach(function (key) {
      if (source[key]) {
        target[key] = source[key];
      }
    });
  }

  function mergeRawFields(target, source) {
    if (!source || typeof source !== "object") return;
    Object.keys(source).forEach(function (key) {
      var value = source[key];
      if (value == null || value === "") return;
      target[key] = value;
    });
  }

  function syncDebugFields(state) {
    state.summary.scan_debug = {
      requested_routes: state.routeDebug.slice(),
      section_names: Object.keys(state.sections).sort(),
      raw_response_count: state.rawResponses.length
    };
  }

  function ensureSection(state, name) {
    if (!state.sections[name]) {
      state.sections[name] = {
        response_count: 0,
        response_urls: [],
        routes: []
      };
    }
    return state.sections[name];
  }

  function recordKey(record) {
    var historyId = "";
    var firstItem = record && record.payload && Array.isArray(record.payload.data) ? record.payload.data[0] : null;
    if (firstItem && firstItem.id) {
      historyId = cleanText(firstItem.id);
    }
    return [record.section, record.response_url, record.route, historyId].join("|");
  }

  function consumeRecord(record) {
    var state = ensureCaptureState();
    if (!state || !record) return;
    if (record.ticker && record.ticker !== state.symbol) return;
    var key = recordKey(record);
    if (state.rawResponseKeys[key]) return;
    state.rawResponseKeys[key] = true;

    if (state.rawResponses.length < MAX_RAW_RESPONSES) {
      state.rawResponses.push(record);
    }

    var section = ensureSection(state, record.section);
    section.response_count += 1;
    if (record.response_url && section.response_urls.indexOf(record.response_url) === -1) {
      section.response_urls.push(record.response_url);
    }
    if (record.route && section.routes.indexOf(record.route) === -1) {
      section.routes.push(record.route);
    }

    var patch = extractSummaryPatch(record.payload, record.response_url);
    if (patch.quant_score != null) state.summary.quant_score = patch.quant_score;
    if (patch.rating) state.summary.rating = patch.rating;
    if (patch.author_rating) state.summary.author_rating = patch.author_rating;
    if (patch.wall_st_rating) state.summary.wall_st_rating = patch.wall_st_rating;
    mergeGrades(state.summary.grades, patch.grades);
    mergeRawFields(state.summary.raw_fields, patch.raw_fields);
    syncDebugFields(state);
    scheduleFlush();
  }

  function buildRecordFromPayload(payload, responseUrl, frameUrl) {
    if (!isInterestingPayload(payload, responseUrl, frameUrl)) return null;
    var frameHref = normalizeHref(frameUrl || window.location.href);
    var responseHref = normalizeHref(responseUrl || frameHref, frameHref);
    var ticker = symbolFromHref(frameHref) || symbolFromHref(responseHref) || symbolFromLocation();
    if (!ticker) return null;

    var serializable = clonePayload(payload);
    if (serializable == null) return null;

    return {
      ticker: ticker,
      section: classifySection(responseHref, frameHref, serializable),
      response_url: responseHref,
      frame_url: frameHref,
      route: frameHref,
      captured_at: new Date().toISOString(),
      payload: serializable
    };
  }

  function publishRecord(record) {
    if (!record) return;
    if (isTopFrame()) {
      consumeRecord(record);
      return;
    }
    try {
      window.top.postMessage({ __brc_sa_record: true, record: record }, window.location.origin);
    } catch (err) {
      try {
        window.top.postMessage({ __brc_sa_record: true, record: record }, "*");
      } catch (innerErr) {
        // ignore messaging errors
      }
    }
  }

  function inspectTextBody(text, responseUrl) {
    if (!text || text.length > 1_000_000) return;
    var parsed;
    try {
      parsed = JSON.parse(text);
    } catch (err) {
      return;
    }
    publishRecord(buildRecordFromPayload(parsed, responseUrl, window.location.href));
  }

  function hasSummarySignal(summary) {
    if (!summary || typeof summary !== "object") return false;
    if (summary.quant_score != null || summary.rating) return true;
    return !!(summary.grades && Object.keys(summary.grades).length);
  }

  function buildCapturePayload() {
    var state = ensureCaptureState();
    if (!state) return null;
    syncDebugFields(state);

    var summary = clonePayload(state.summary) || {};
    summary.raw_fields = summary.raw_fields || {};
    summary.raw_fields.source = CAPTURE_SOURCE;
    summary.raw_fields.extension_version = EXT_VERSION;
    summary.raw_fields.section_names = Object.keys(state.sections).sort();
    summary.raw_fields.raw_response_count = state.rawResponses.length;

    return {
      ticker: state.symbol,
      url: state.pageUrl,
      title: summary.title || cleanText(document.title),
      page_type: "symbol",
      captured_at: new Date().toISOString(),
      bookmarklet_version: summary.bookmarklet_version,
      source: CAPTURE_SOURCE,
      source_ref: state.pageUrl,
      rating: summary.rating || "",
      quant_score: summary.quant_score,
      author_rating: summary.author_rating || "",
      wall_st_rating: summary.wall_st_rating || "",
      grades: summary.grades || {},
      summary: summary,
      sections: clonePayload(state.sections) || {},
      raw_responses: clonePayload(state.rawResponses) || []
    };
  }

  function postSnapshot(payload) {
    if (!endpoint) return Promise.reject(new Error("BRC endpoint not configured"));
    return fetch(endpoint.replace(/\/$/, "") + "/api/webhooks/sa_symbol_capture", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      credentials: "omit"
    }).then(function (resp) {
      return resp.text().then(function (body) {
        if (!resp.ok) {
          throw new Error("HTTP " + resp.status + " " + body.slice(0, 200));
        }
        return body;
      });
    });
  }

  function flushSnapshot() {
    var state = ensureCaptureState();
    if (!state || state.posted || state.pendingRoutes > 0 || !endpoint) return;
    var payload = buildCapturePayload();
    if (!payload) return;
    if (!payload.raw_responses.length && !hasSummarySignal(payload.summary)) return;

    state.posted = true;
    postSnapshot(payload).then(function () {
      console.log("[BRC SA] symbol snapshot captured", payload.ticker, Object.keys(payload.sections).length);
    }).catch(function (err) {
      state.posted = false;
      console.warn("[BRC SA] symbol snapshot failed", err && err.message ? err.message : err);
    });
  }

  function scheduleFlush() {
    var state = ensureCaptureState();
    if (!state) return;
    if (state.flushTimer) {
      clearTimeout(state.flushTimer);
    }
    state.flushTimer = setTimeout(function () {
      state.flushTimer = 0;
      flushSnapshot();
    }, FLUSH_IDLE_MS);
  }

  function appendRouteDebug(route, status) {
    var state = ensureCaptureState();
    if (!state) return;
    state.routeDebug.push({
      url: route.url,
      section: route.section,
      via: route.via,
      status: status
    });
    syncDebugFields(state);
  }

  function routeSectionFromUrl(url) {
    return classifySection(url, url, null);
  }

  function collectDomRoutes(symbol) {
    var prefix = "/symbol/" + symbol + "/";
    var seen = {};
    var routes = [];
    var anchors = document.querySelectorAll("a[href]");

    for (var i = 0; i < anchors.length; i++) {
      var normalized = normalizeHref(anchors[i].getAttribute("href"), window.location.href);
      if (!normalized || normalized === normalizeHref(window.location.href)) continue;
      try {
        var url = new URL(normalized);
        if (url.origin !== window.location.origin) continue;
        if (url.pathname.indexOf(prefix) !== 0) continue;
        if (!/(ratings|valuation|earnings|dividend|financial|peer)/i.test(url.pathname)) continue;
        if (seen[normalized]) continue;
        seen[normalized] = true;
        routes.push({
          section: routeSectionFromUrl(normalized),
          url: normalized,
          via: "dom_link"
        });
      } catch (err) {
        // ignore malformed urls
      }
    }

    return routes;
  }

  function collectRouteCandidates(symbol) {
    var state = ensureCaptureState();
    if (!state) return [];
    var seen = {};
    var routes = [];

    function addRoute(section, url, via) {
      var normalized = normalizeHref(url, window.location.origin);
      if (!normalized || normalized === state.pageUrl) return;
      if (symbolFromHref(normalized) !== symbol) return;
      if (seen[normalized]) return;
      seen[normalized] = true;
      routes.push({ section: section || routeSectionFromUrl(normalized), url: normalized, via: via });
    }

    collectDomRoutes(symbol).forEach(function (route) {
      addRoute(route.section, route.url, route.via);
    });

    FALLBACK_ROUTE_SPECS.forEach(function (spec) {
      addRoute(spec.section, window.location.origin + "/symbol/" + symbol + spec.suffix, "fallback");
    });

    return routes.slice(0, 14);
  }

  function hiddenContainer() {
    var existing = document.getElementById(HIDDEN_CONTAINER_ID);
    if (existing) return existing;
    var container = document.createElement("div");
    container.id = HIDDEN_CONTAINER_ID;
    container.style.display = "none";
    (document.body || document.documentElement).appendChild(container);
    return container;
  }

  function finishRoute(route, iframe) {
    if (route.done) return;
    route.done = true;
    if (iframe && iframe.parentNode) {
      iframe.parentNode.removeChild(iframe);
    }
    var state = ensureCaptureState();
    if (!state) return;
    state.pendingRoutes = Math.max(0, state.pendingRoutes - 1);
    appendRouteDebug(route, route.finalStatus || "done");
    scheduleFlush();
  }

  function loadRouteInFrame(route) {
    var state = ensureCaptureState();
    if (!state) return;
    state.pendingRoutes += 1;
    appendRouteDebug(route, "queued");

    var iframe = document.createElement("iframe");
    iframe.src = route.url;
    iframe.style.display = "none";
    iframe.referrerPolicy = "strict-origin-when-cross-origin";

    var settled = false;
    function complete(status) {
      if (settled) return;
      settled = true;
      route.finalStatus = status;
      finishRoute(route, iframe);
    }

    iframe.addEventListener("load", function () {
      appendRouteDebug(route, "loaded");
      setTimeout(function () {
        complete("settled");
      }, FRAME_SETTLE_MS);
    });
    iframe.addEventListener("error", function () {
      complete("error");
    });

    setTimeout(function () {
      complete("timeout");
    }, FRAME_MAX_MS);

    hiddenContainer().appendChild(iframe);
  }

  function startRouteCapture() {
    var state = ensureCaptureState();
    if (!state || state.started) return;
    state.started = true;
    var routes = collectRouteCandidates(state.symbol);
    if (!routes.length) {
      scheduleFlush();
      return;
    }
    routes.forEach(loadRouteInFrame);
    scheduleFlush();
  }

  document.documentElement.addEventListener("brc-sa-endpoint", function (event) {
    endpoint = cleanText(event && event.detail && event.detail.endpoint);
    scheduleFlush();
    if (isTopFrame()) {
      setTimeout(startRouteCapture, 400);
    }
  });

  if (isTopFrame()) {
    window.addEventListener("message", function (event) {
      if (event.origin && event.origin !== window.location.origin) return;
      var data = event.data;
      if (!data || !data.__brc_sa_record || !data.record) return;
      consumeRecord(data.record);
    }, false);

    ensureCaptureState();
    setTimeout(startRouteCapture, 900);
  }

  var originalFetch = window.fetch;
  if (typeof originalFetch === "function") {
    window.fetch = function () {
      return originalFetch.apply(this, arguments).then(function (response) {
        try {
          response.clone().text().then(function (body) {
            inspectTextBody(body, response.url);
          }).catch(function () {});
        } catch (err) {
          // ignore clone/body errors
        }
        return response;
      });
    };
  }

  var originalOpen = XMLHttpRequest.prototype.open;
  var originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this.__brcUrl = url;
    return originalOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function () {
    this.addEventListener("load", function () {
      try {
        inspectTextBody(this.responseText, this.responseURL || this.__brcUrl || "");
      } catch (err) {
        // ignore non-text responses
      }
    });
    return originalSend.apply(this, arguments);
  };
})();
