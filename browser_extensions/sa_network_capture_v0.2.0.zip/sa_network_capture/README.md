# BRC SA Network Capture

Captures full Seeking Alpha symbol snapshots from the authenticated browser and forwards them to `sa_symbol_capture`.

## Install

1. Open `chrome://extensions`
2. Enable `Developer mode`
3. Click `Load unpacked`
4. Select this folder: `browser_extensions/sa_network_capture`
5. Open the extension `Details` page
6. Click `Extension options`
7. Set the BoxRoomCapital endpoint to your app base URL

Example endpoint:

`https://your-replit-app.replit.dev`

Do not include a trailing slash or any path.

## Use

1. Stay logged into Seeking Alpha in Chrome
2. Open a symbol page such as `https://seekingalpha.com/symbol/MU`
3. Let the page finish loading
4. The extension opens hidden same-origin symbol routes, listens for the page's own JSON responses, and forwards one merged snapshot automatically

## What it sends

- top-level symbol metadata: `ticker`, `url`, `title`, `page_type=symbol`
- normalized summary fields: `quant_score`, `rating`, `author_rating`, `wall_st_rating`, `grades`
- `sections`: response metadata grouped by symbol route family
- `raw_responses`: the JSON payloads captured from the symbol routes
- the first ratings-history entry is still normalized into the summary so the existing SA signal path continues to work

## Current behavior

- Works on live symbol pages without DOM tab scraping
- Loads high-value symbol routes in hidden iframes instead of touching the visible UI
- Posts one aggregated symbol snapshot per page session
- Dedupe is done per section + response URL + history id in the page session
