(function () {
  var EXT_VERSION = (document.currentScript && document.currentScript.dataset.extensionVersion) || "0.2.2";
  var CAPTURE_SOURCE = "sa-network-extension";
  var TAB_WAIT_MS = 1800;
  var FLUSH_IDLE_MS = 1500;
  var MAX_RAW_RESPONSES = 32;
  var endpoint = "";
  var captureState = null;
  var GRADE_MAP = {
    1: "F",
    2: "D-",
    3: "D",
    4: "D+",
    5: "C-",
    6: "C",
    7: "C+",
    8: "B-",
    9: "B",
    10: "B+",
    11: "A-",
    12: "A",
    13: "A+"
  };
  var TAB_LABEL_PATTERNS = [
    { section: "quant_ratings", pattern: /quant/i, score: 200 },
    { section: "author_ratings", pattern: /author|sa analysts?/i, score: 180 },
    { section: "sell_side_ratings", pattern: /sell[- ]side|wall st|wall street|analysts?/i, score: 170 },
    { section: "valuation", pattern: /valuation|value/i, score: 140 },
    { section: "financials", pattern: /financial|income|balance sheet|cash flow/i, score: 130 },
    { section: "earnings", pattern: /earnings|revision|transcript/i, score: 120 },
    { section: "dividends", pattern: /dividend|yield/i, score: 110 },
    { section: "peers", pattern: /peer|comparison/i, score: 100 },
    { section: "symbol", pattern: /growth|profitability|momentum/i, score: 90 }
  ];

  function cleanText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function debugVersion() {
    return "sa-network-extension-" + EXT_VERSION;
  }

  function isTopFrame() {
    try {
      return window.top === window;
    } catch (err) {
      return false;
    }
  }

  function normalizeHref(href, baseHref) {
    try {
      var url = new URL(href, baseHref || window.location.href);
      url.hash = "";
      return url.toString();
    } catch (err) {
      return "";
    }
  }

  function symbolFromPath(pathname) {
    var match = String(pathname || "").match(/\/symbol\/([A-Z0-9.=\-]+)/i);
    return match ? match[1].toUpperCase() : "";
  }

  function symbolFromHref(href) {
    try {
      return symbolFromPath(new URL(href, window.location.href).pathname);
    } catch (err) {
      return "";
    }
  }

  function symbolFromLocation() {
    return symbolFromPath(window.location.pathname || "");
  }

  function toNumber(value) {
    if (value == null || value === "") return null;
    var numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
  }

  function ratingFromScore(score) {
    var numeric = toNumber(score);
    if (numeric == null) return "";
    if (numeric >= 4.5) return "strong buy";
    if (numeric >= 3.5) return "buy";
    if (numeric >= 2.5) return "hold";
    if (numeric >= 1.5) return "sell";
    return "strong sell";
  }

  function gradeFromNumeric(value) {
    var numeric = toNumber(value);
    if (numeric == null) return "";
    var rounded = Math.round(numeric);
    return GRADE_MAP[rounded] || "";
  }

  function latestHistoryEntry(payload) {
    var data = payload && payload.data;
    if (!Array.isArray(data)) return null;
    for (var i = 0; i < data.length; i++) {
      var item = data[i];
      var attrs = item && item.attributes;
      var ratings = attrs && attrs.ratings;
      if (!ratings || typeof ratings !== "object") continue;
      if (ratings.quantRating == null && ratings.sellSideRating == null && ratings.authorsRating == null) {
        continue;
      }
      return item;
    }
    return null;
  }

  function clonePayload(value) {
    try {
      return JSON.parse(JSON.stringify(value));
    } catch (err) {
      return null;
    }
  }

  function isVisibleElement(el) {
    if (!el || typeof el.getBoundingClientRect !== "function") return false;
    if (el.hidden) return false;
    var style = window.getComputedStyle(el);
    if (!style || style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
      return false;
    }
    var rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isInterestingPayload(payload, responseUrl, frameUrl) {
    if (!payload || typeof payload !== "object") return false;
    var responseHref = cleanText(responseUrl).toLowerCase();
    var frameHref = cleanText(frameUrl).toLowerCase();
    var combined = [responseHref, frameHref].join(" ");
    if (!/https:\/\/seekingalpha\.com\//.test(responseHref)) return false;
    if (latestHistoryEntry(payload)) return true;
    if (!/\/api\/v3\//.test(responseHref)) return false;
    if (/\/(ab_tests|breaking_news|market_open|visitor_tag_for_url_params)\b/.test(responseHref)) return false;
    if (/symbol_data/.test(responseHref)) return true;
    return /(ratings|quant|valuation|earnings|dividend|financial|peer|symbol_data)/.test(combined);
  }

  function classifySection(responseUrl, frameUrl, payload) {
    var url = cleanText(responseUrl || frameUrl || "").toLowerCase();
    if (latestHistoryEntry(payload)) return "ratings_history";
    if (url.indexOf("/ratings/quant-ratings") !== -1) return "quant_ratings";
    if (url.indexOf("/ratings/author-ratings") !== -1) return "author_ratings";
    if (url.indexOf("/ratings/sell-side-ratings") !== -1) return "sell_side_ratings";
    if (url.indexOf("/valuation/") !== -1) return "valuation";
    if (url.indexOf("/earnings/") !== -1) return "earnings";
    if (url.indexOf("/dividend") !== -1 || url.indexOf("/dividends/") !== -1) return "dividends";
    if (
      url.indexOf("/financial") !== -1 ||
      url.indexOf("income-statement") !== -1 ||
      url.indexOf("balance-sheet") !== -1 ||
      url.indexOf("cash-flow") !== -1
    ) {
      return "financials";
    }
    if (url.indexOf("/peers/") !== -1) return "peers";
    if (url.indexOf("symbol_data") !== -1 && /(peRatioFwd|estimateEps|estimateFfo|lastClosePriceEarningsRatio)/i.test(url)) {
      return "valuation";
    }
    return "symbol";
  }

  function extractSummaryPatch(payload, responseUrl) {
    var entry = latestHistoryEntry(payload);
    if (!entry) return {};

    var attrs = entry.attributes || {};
    var ratings = attrs.ratings || {};
    return {
      quant_score: toNumber(ratings.quantRating),
      rating: ratingFromScore(ratings.quantRating),
      author_rating: ratingFromScore(ratings.authorsRating),
      wall_st_rating: ratingFromScore(ratings.sellSideRating),
      grades: {
        value: gradeFromNumeric(ratings.valueGrade),
        growth: gradeFromNumeric(ratings.growthGrade),
        profitability: gradeFromNumeric(ratings.profitabilityGrade),
        momentum: gradeFromNumeric(ratings.momentumGrade),
        revisions: gradeFromNumeric(
          ratings.epsRevisionsGrade != null ? ratings.epsRevisionsGrade : ratings.revisionsGrade
        )
      },
      raw_fields: {
        response_url: cleanText(responseUrl || ""),
        as_date: cleanText(attrs.asDate || ""),
        ticker_id: attrs.tickerId != null ? attrs.tickerId : null,
        sa_history_id: cleanText(entry.id || "")
      }
    };
  }

  function createInitialSummary(symbol) {
    var pageUrl = normalizeHref(window.location.href);
    return {
      ticker: symbol,
      url: pageUrl,
      title: cleanText(document.title),
      page_type: "symbol",
      captured_at: new Date().toISOString(),
      rating: "",
      quant_score: null,
      author_rating: "",
      wall_st_rating: "",
      grades: {},
      bookmarklet_version: debugVersion(),
      source: CAPTURE_SOURCE,
      source_ref: pageUrl,
      raw_fields: {
        source: CAPTURE_SOURCE,
        extension_version: EXT_VERSION
      }
    };
  }

  function sendDebugPing(stage, extra) {
    if (!endpoint) return;
    try {
      var url = endpoint.replace(/\/$/, "") + "/api/webhooks/sa_debug_ping"
        + "?stage=" + encodeURIComponent(stage || "")
        + "&v=" + encodeURIComponent(debugVersion())
        + "&href=" + encodeURIComponent(normalizeHref(window.location.href))
        + "&host=" + encodeURIComponent(window.location.host || "")
        + "&page_type=symbol";
      if (extra && typeof extra === "object") {
        Object.keys(extra).forEach(function (key) {
          if (extra[key] == null || extra[key] === "") return;
          url += "&" + encodeURIComponent(key) + "=" + encodeURIComponent(String(extra[key]));
        });
      }
      var img = new Image();
      img.referrerPolicy = "no-referrer";
      img.src = url;
    } catch (err) {
      // ignore debug ping errors
    }
  }

  function ensureCaptureState() {
    if (!isTopFrame()) return null;
    if (captureState) return captureState;
    var symbol = symbolFromLocation();
    if (!symbol) return null;
    var pageUrl = normalizeHref(window.location.href);
    captureState = {
      symbol: symbol,
      pageUrl: pageUrl,
      started: false,
      posted: false,
      postedFingerprint: "",
      pendingRoutes: 0,
      rawResponses: [],
      rawResponseKeys: {},
      sections: {},
      routeDebug: [{ source: "current_page", url: pageUrl }],
      summary: createInitialSummary(symbol),
      flushTimer: 0
    };
    syncDebugFields(captureState);
    return captureState;
  }

  function mergeGrades(target, source) {
    if (!source || typeof source !== "object") return;
    Object.keys(source).forEach(function (key) {
      if (source[key]) {
        target[key] = source[key];
      }
    });
  }

  function mergeRawFields(target, source) {
    if (!source || typeof source !== "object") return;
    Object.keys(source).forEach(function (key) {
      var value = source[key];
      if (value == null || value === "") return;
      target[key] = value;
    });
  }

  function syncDebugFields(state) {
    state.summary.scan_debug = {
      requested_routes: state.routeDebug.slice(),
      section_names: Object.keys(state.sections).sort(),
      raw_response_count: state.rawResponses.length
    };
  }

  function ensureSection(state, name) {
    if (!state.sections[name]) {
      state.sections[name] = {
        response_count: 0,
        response_urls: [],
        routes: []
      };
    }
    return state.sections[name];
  }

  function recordKey(record) {
    var historyId = "";
    var firstItem = record && record.payload && Array.isArray(record.payload.data) ? record.payload.data[0] : null;
    if (firstItem && firstItem.id) {
      historyId = cleanText(firstItem.id);
    }
    return [record.section, record.response_url, record.route, historyId].join("|");
  }

  function consumeRecord(record) {
    var state = ensureCaptureState();
    if (!state || !record) return;
    if (record.ticker && record.ticker !== state.symbol) return;
    var key = recordKey(record);
    if (state.rawResponseKeys[key]) return;
    state.rawResponseKeys[key] = true;
    state.posted = false;

    if (state.rawResponses.length < MAX_RAW_RESPONSES) {
      state.rawResponses.push(record);
    }

    var section = ensureSection(state, record.section);
    section.response_count += 1;
    if (record.response_url && section.response_urls.indexOf(record.response_url) === -1) {
      section.response_urls.push(record.response_url);
    }
    if (record.route && section.routes.indexOf(record.route) === -1) {
      section.routes.push(record.route);
    }

    var patch = extractSummaryPatch(record.payload, record.response_url);
    if (patch.quant_score != null) state.summary.quant_score = patch.quant_score;
    if (patch.rating) state.summary.rating = patch.rating;
    if (patch.author_rating) state.summary.author_rating = patch.author_rating;
    if (patch.wall_st_rating) state.summary.wall_st_rating = patch.wall_st_rating;
    mergeGrades(state.summary.grades, patch.grades);
    mergeRawFields(state.summary.raw_fields, patch.raw_fields);
    syncDebugFields(state);
    scheduleFlush();
  }

  function buildRecordFromPayload(payload, responseUrl, frameUrl) {
    if (!isInterestingPayload(payload, responseUrl, frameUrl)) return null;
    var frameHref = normalizeHref(frameUrl || window.location.href);
    var responseHref = normalizeHref(responseUrl || frameHref, frameHref);
    var ticker = symbolFromHref(frameHref) || symbolFromHref(responseHref) || symbolFromLocation();
    if (!ticker) return null;

    var serializable = clonePayload(payload);
    if (serializable == null) return null;

    return {
      ticker: ticker,
      section: classifySection(responseHref, frameHref, serializable),
      response_url: responseHref,
      frame_url: frameHref,
      route: frameHref,
      captured_at: new Date().toISOString(),
      payload: serializable
    };
  }

  function publishRecord(record) {
    if (!record) return;
    if (isTopFrame()) {
      consumeRecord(record);
      return;
    }
    try {
      window.top.postMessage({ __brc_sa_record: true, record: record }, window.location.origin);
    } catch (err) {
      try {
        window.top.postMessage({ __brc_sa_record: true, record: record }, "*");
      } catch (innerErr) {
        // ignore messaging errors
      }
    }
  }

  function inspectTextBody(text, responseUrl) {
    if (!text || text.length > 1_000_000) return;
    var parsed;
    try {
      parsed = JSON.parse(text);
    } catch (err) {
      return;
    }
    publishRecord(buildRecordFromPayload(parsed, responseUrl, window.location.href));
  }

  function hasSummarySignal(summary) {
    if (!summary || typeof summary !== "object") return false;
    if (summary.quant_score != null || summary.rating) return true;
    return !!(summary.grades && Object.keys(summary.grades).length);
  }

  function buildCapturePayload() {
    var state = ensureCaptureState();
    if (!state) return null;
    syncDebugFields(state);

    var summary = clonePayload(state.summary) || {};
    summary.raw_fields = summary.raw_fields || {};
    summary.raw_fields.source = CAPTURE_SOURCE;
    summary.raw_fields.extension_version = EXT_VERSION;
    summary.raw_fields.section_names = Object.keys(state.sections).sort();
    summary.raw_fields.raw_response_count = state.rawResponses.length;

    return {
      ticker: state.symbol,
      url: state.pageUrl,
      title: summary.title || cleanText(document.title),
      page_type: "symbol",
      captured_at: new Date().toISOString(),
      bookmarklet_version: summary.bookmarklet_version,
      source: CAPTURE_SOURCE,
      source_ref: state.pageUrl,
      rating: summary.rating || "",
      quant_score: summary.quant_score,
      author_rating: summary.author_rating || "",
      wall_st_rating: summary.wall_st_rating || "",
      grades: summary.grades || {},
      summary: summary,
      sections: clonePayload(state.sections) || {},
      raw_responses: clonePayload(state.rawResponses) || []
    };
  }

  function postSnapshot(payload) {
    if (!endpoint) return Promise.reject(new Error("BRC endpoint not configured"));
    return fetch(endpoint.replace(/\/$/, "") + "/api/webhooks/sa_symbol_capture", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      credentials: "omit"
    }).then(function (resp) {
      return resp.text().then(function (body) {
        if (!resp.ok) {
          throw new Error("HTTP " + resp.status + " " + body.slice(0, 200));
        }
        return body;
      });
    });
  }

  function flushSnapshot() {
    var state = ensureCaptureState();
    if (!state || state.pendingRoutes > 0 || !endpoint) return;
    var payload = buildCapturePayload();
    if (!payload) return;
    if (!payload.raw_responses.length && !hasSummarySignal(payload.summary)) return;
    var fingerprint = JSON.stringify({
      raw_count: payload.raw_responses.length,
      sections: Object.keys(payload.sections).sort(),
      quant_score: payload.summary && payload.summary.quant_score,
      rating: payload.summary && payload.summary.rating
    });
    if (state.posted && state.postedFingerprint === fingerprint) return;

    state.posted = true;
    state.postedFingerprint = fingerprint;
    console.log("[BRC SA] posting snapshot", payload.ticker, Object.keys(payload.sections).length, payload.raw_responses.length, debugVersion());
    sendDebugPing("pre_post", {
      sections: Object.keys(payload.sections).length,
      raw_count: payload.raw_responses.length
    });
    postSnapshot(payload).then(function () {
      console.log("[BRC SA] symbol snapshot captured", payload.ticker, Object.keys(payload.sections).length);
      sendDebugPing("post_ok", {
        sections: Object.keys(payload.sections).length,
        raw_count: payload.raw_responses.length
      });
    }).catch(function (err) {
      state.posted = false;
      console.warn("[BRC SA] symbol snapshot failed", err && err.message ? err.message : err);
      sendDebugPing("post_fail", {
        message: err && err.message ? err.message : String(err || "")
      });
    });
  }

  function scheduleFlush() {
    var state = ensureCaptureState();
    if (!state) return;
    if (state.flushTimer) {
      clearTimeout(state.flushTimer);
    }
    state.flushTimer = setTimeout(function () {
      state.flushTimer = 0;
      flushSnapshot();
    }, FLUSH_IDLE_MS);
  }

  function appendRouteDebug(route, status) {
    var state = ensureCaptureState();
    if (!state) return;
    state.routeDebug.push({
      url: route.url,
      section: route.section,
      via: route.via,
      status: status
    });
    syncDebugFields(state);
  }

  function tabSpecForLabel(label) {
    var clean = cleanText(label);
    if (!clean) return null;
    var best = null;
    for (var i = 0; i < TAB_LABEL_PATTERNS.length; i++) {
      var spec = TAB_LABEL_PATTERNS[i];
      if (!spec.pattern.test(clean)) continue;
      if (!best || spec.score > best.score) {
        best = { section: spec.section, score: spec.score };
      }
    }
    return best;
  }

  function collectVisibleTabs() {
    var seen = {};
    var items = [];
    var selector = [
      '[role=\"tab\"]',
      '[role=\"tablist\"] button',
      'button[aria-controls]',
      'button[data-test-id*=\"tab\"]',
      'button[class*=\"tab\"]'
    ].join(',');

    document.querySelectorAll(selector).forEach(function (el) {
      if (!isVisibleElement(el)) return;
      var label = cleanText(el.textContent || el.getAttribute('aria-label') || el.title || '');
      if (!label || label.length > 60) return;
      var spec = tabSpecForLabel(label);
      if (!spec) return;
      var key = label.toLowerCase();
      if (seen[key]) return;
      seen[key] = true;
      items.push({
        element: el,
        label: label,
        section: spec.section,
        score: spec.score
      });
    });

    items.sort(function (a, b) {
      return b.score - a.score || a.label.localeCompare(b.label);
    });
    return items.slice(0, 10);
  }

  function clickVisibleTab(item) {
    return new Promise(function (resolve) {
      try {
        item.element.scrollIntoView({ behavior: "instant", block: "center", inline: "center" });
      } catch (err) {
        // ignore scroll errors
      }
      try {
        item.element.click();
      } catch (err) {
        item.element.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
      }
      setTimeout(resolve, TAB_WAIT_MS);
    });
  }

  async function startRouteCapture() {
    var state = ensureCaptureState();
    if (!state || state.started) return;
    state.started = true;
    state.pendingRoutes += 1;
    var tabs = collectVisibleTabs();
    console.log("[BRC SA] tab scan", debugVersion(), tabs.map(function (t) { return t.label; }));
    sendDebugPing("tab_scan", { tabs: tabs.length });
    if (!tabs.length) {
      state.pendingRoutes = Math.max(0, state.pendingRoutes - 1);
      scheduleFlush();
      return;
    }

    for (var i = 0; i < tabs.length; i++) {
      var route = {
        url: state.pageUrl,
        section: tabs[i].section,
        via: "visible_tab",
        label: tabs[i].label
      };
      appendRouteDebug(route, "queued");
      try {
        await clickVisibleTab(tabs[i]);
        appendRouteDebug(route, "clicked");
      } catch (err) {
        appendRouteDebug(route, "error");
      }
    }

    state.pendingRoutes = Math.max(0, state.pendingRoutes - 1);
    scheduleFlush();
  }

  document.documentElement.addEventListener("brc-sa-endpoint", function (event) {
    endpoint = cleanText(event && event.detail && event.detail.endpoint);
    console.log("[BRC SA] endpoint", endpoint ? "set" : "missing", debugVersion());
    if (endpoint) {
      sendDebugPing("endpoint_set");
    }
    scheduleFlush();
    if (isTopFrame()) {
      setTimeout(startRouteCapture, 400);
    }
  });

  if (isTopFrame()) {
    console.log("[BRC SA] hook active", debugVersion(), normalizeHref(window.location.href));
    window.addEventListener("message", function (event) {
      if (event.origin && event.origin !== window.location.origin) return;
      var data = event.data;
      if (!data || !data.__brc_sa_record || !data.record) return;
      consumeRecord(data.record);
    }, false);

    ensureCaptureState();
    setTimeout(startRouteCapture, 900);
  }

  var originalFetch = window.fetch;
  if (typeof originalFetch === "function") {
    window.fetch = function () {
      return originalFetch.apply(this, arguments).then(function (response) {
        try {
          response.clone().text().then(function (body) {
            inspectTextBody(body, response.url);
          }).catch(function () {});
        } catch (err) {
          // ignore clone/body errors
        }
        return response;
      });
    };
  }

  var originalOpen = XMLHttpRequest.prototype.open;
  var originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this.__brcUrl = url;
    return originalOpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function () {
    this.addEventListener("load", function () {
      try {
        inspectTextBody(this.responseText, this.responseURL || this.__brcUrl || "");
      } catch (err) {
        // ignore non-text responses
      }
    });
    return originalSend.apply(this, arguments);
  };
})();
